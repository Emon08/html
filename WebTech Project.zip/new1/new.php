<?php include('server.php')?>
<?php 
 /* session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }*/
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"new1/image/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }
   }
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="top">
	<h1>House Rental Web Portal</h1>
	<div class="toplinks">
	<a href ="login.php">LOGIN </a>
	<a href ="register.php">SIGN UP </a>
	</div>
</div>
<div class="topnav">
	<a href ="index.php">HOMEPAGE </a>
	<a href ="profilepage.php">PROFILE </a>
	<a href ="buy.php">BUY</a> 
    <a href ="rent.php">RENT</a>
	<a href ="new.php">NEW</a>
	<a href ="highestrated.php">HIGHEST RATED</a>
	<input class="search" type="text" placeholder="Search.." name= "search" >             
</div>
<div class="content">
  	
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
	
	        <form method="post" action="new.php">
					
			<?php include('errors.php'); ?>
               <div class="input-group">
  	  <label>BDT</label>
  	  <input type="text" name="bdt" value="<?php echo $bdt; ?>" >
  	</div>
  	<div class="input-group">
  	  <label>ADDRESS</label>
  	  <input type="text" name="address" value="<?php echo $address; ?>" >
  	</div>
	<div class="input-group">
  	  <label>TYPE</label>
	  <select name="type">
  <option value="Apartment">Apartment</option>
  <option value="House">House</option>
  <option value="Bungalow">Bungalow</option>
  <option value="Hallroom">Hallroom</option>
  <option value="Office">Office</option>
</select>
  	</div>
  	<div class="input-group">
  	  <label>AREA</label>
  	  <input type="text" name="area" value="<?php echo $area; ?>">
  	</div>
	
	<div class="input-group">
				<label>Image</label>
				<input type="file" name = "image" value="<?php echo $image; ?>">
                    
					</div>
					
	
  	<div class="input-group">
  	  <label>NUMBER</label>
  	  <input type="text" name="number" value="<?php echo $number; ?>">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="createrent">CREATE RENT</button>
  	</div>
					
               
              
	 </form>		
			
</div>
		
</body>
</html>














