-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2018 at 04:24 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(100) DEFAULT NULL,
  `bdt` int(50) NOT NULL,
  `address` varchar(50) COLLATE utf8_bin NOT NULL,
  `type` varchar(50) COLLATE utf8_bin NOT NULL,
  `area` varchar(50) COLLATE utf8_bin NOT NULL,
  `image` varchar(100) COLLATE utf8_bin NOT NULL,
  `number` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `bdt`, `address`, `type`, `area`, `image`, `number`) VALUES
(NULL, 50000, 'uttara', 'apartment', '2500', 'download (1).jpg', 174353432),
(NULL, 25000, 'bashundhara', 'apartment', '1500', 'download (2).jpg', 1743534543);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) DEFAULT NULL,
  `username` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `phone` varchar(100) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `phone`, `password`) VALUES
(NULL, 'tanvir', 'tanvirturja@yahoo.com', '', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'anik', 'xahid@gmail.com', '', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'fahim', 'fahim@gmail.com', '01745031351', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'emon', 'emon@yahoo.com', '01895031353', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'adan', 'adon@yahoo.com', '01895087353', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'jolil', 'jolil@gmail.com', '01745031891', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'rafi', 'rafi@gmail.com', '01683158323', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'mobin', 'mobin@gmail.com', '01683158324', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'ironman', 'ironman@yahoo.com', '01356899751', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'joker', 'joker@yahoo.com', '01756899751', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'marzia', 'marzia@gmail.com', '01736446577', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, '1', '1@gmail.com', '0183645373', '6512bd43d9caa6e02c990b0a82652dca'),
(NULL, 'ahsan', 'raefsa@gmail.com', '3982938', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'azizul', 'azizul@gmail.com', '018283633', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'abaal', 'abaal@yahoo.com', '00000000', '74b87337454200d4d33f80c4663dc5e5'),
(NULL, 'coffee', 'coffee@gmail.com', '01683158341', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'boss', 'boss@gmail.com', '01895031353', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'god', 'god@gmail.com', '01745031891', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'venom', 'venom@gmail.com', '01745031891', '827ccb0eea8a706c4c34a16891f84e7b'),
(NULL, 'thor', 'thor@gmail.com', '01895087353', '827ccb0eea8a706c4c34a16891f84e7b');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
