<?php include('server.php')?>
<?php 

  /*session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }*/
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
  ?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="top">
	<h1>House Rental Web Portal</h1>
	<div class="toplinks">
	<a href ="login.php">LOGIN </a>
	<a href ="register.php">SIGN UP </a>
	</div>
</div>
<div class="topnav">
	<a href ="index.php">HOMEPAGE </a>
	<a href ="profilepage.php">PROFILE </a>
	<a href ="buy.php">BUY</a> 
    <a href ="rent.php">RENT</a>
	<a href ="new.php">NEW</a>
	<a href ="highestrated.php">HIGHEST RATED</a>
	<input class="search" type="text" placeholder="Search.." name= "search" >             
</div>
<div class="content">
  	
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
	
	        <form method="post" action="index.php">
		
                
              		<?php
             $sql = "SELECT bdt, address, type, area,image, number FROM home ";
            $resultset = mysqli_query($db, $sql) or die("database error:". mysqli_error($db));			
			while( $record = mysqli_fetch_array($resultset) ) {
				
			?>	
			
			
			
			
                <hr/>
				
                <div class="input-group">
				<label>PRICE:<?php echo $record['bdt']; ?></label> 
				
				</div>
				
                   <div class="input-group">
				<label>ADDRESS:<?php echo $record['address']; ?></label> 
				</div>
				<div class="input-group">
				<label>TYPE:<?php echo $record['type']; ?></label
                    </div>
					<div class="input-group">
				<label>AREA:<?php echo $record['area']; ?></label> 
					</div>
					
					<div class="input-group" >
				<label >IMAGE:<?php  echo "<div id='img_div'>";
					
         	echo "<img src='image/".$record['image']."' >";
      	        // echo "<p>".$record['image_text']."</p>";
            echo "</div>"; ?>
			</label> 
			
                  	</div>
					<div class="input-group">
				<label>CONTACT NUMBER:<?php echo $record['number']; ?></label> 
                   </div>
					<hr/>
					<?php 
			}
					?>
        
             		
              
			
			
</div>
<div class="footer">
	<h3>About Us</h3>
</div>		
</body>
</html>