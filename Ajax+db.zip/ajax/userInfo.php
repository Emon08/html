<?php
include('db.php');

$name = $_POST['name'];
$age  = $_POST['age'];

$sql = "INSERT INTO user(name,age)
VALUES ('$name','$age')";

if(mysqli_query($conn,$sql))
	echo "Successfully Inserted";
else
	echo "Insertion Failed";
?>