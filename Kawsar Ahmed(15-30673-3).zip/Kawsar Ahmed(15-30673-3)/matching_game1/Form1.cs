﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matching_game1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int l = 0;
        int Match = 8;
        int time = 60;
        PictureBox firstclick;
       
        void font()
            
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Image = Properties.Resources._0;
                }
            }
        }
        void back()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Tag = "0";
                }
            }
        }
        void tag()
        {
            int[] matching = new int[16];
            Random selete = new Random();
            int i = 0;
            while (i < 16)
            {
                int s = selete.Next(1, 17);
                if (Array.IndexOf(matching, s) == -1)
                {
                    matching[i] = s;
                    i++;
                }
            }
            for (int a = 0; a < 16; a++)
            {
                if (matching[a] > 8) matching[a] -= 8;
            }
            int b = 0;
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    p.Tag = matching[b].ToString();
                    b++;
                }
            }
        }
        void click(PictureBox firstclick, PictureBox secondcick)
        {
            if (firstclick.Tag.ToString() == secondcick.Tag.ToString())
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(400);
                firstclick.Visible = false;
                secondcick.Visible = false;

                Match--;
                if (Match == 0)
                {
                    Left.Text = "Congrats!";
                    timer1.Enabled = false;
                }
                else
                    Left.Text = "Remainer =" + Match;


            }
            else
            {
                Application.DoEvents();
                System.Threading.Thread.Sleep(350);
                firstclick.Image = Image.FromFile("0.png");
                secondcick.Image = Image.FromFile("0.png");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            font();
            back();
            tag();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            PictureBox secondclick = (sender as PictureBox);
            secondclick.Image = Image.FromFile((sender as PictureBox).Tag.ToString() + ".png");
            if (l == 0)
            {
                firstclick = secondclick;
                l++;

            }
            else
            {
                if (firstclick == secondclick)
                {
                    MessageBox.Show("Try Another");

                    l = 0;
                    firstclick.Image = Image.FromFile("0.png");
                }
                else
                {
                    click(firstclick, secondclick);
                    l = 0;
                }
            }
        }
        void show()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Image = Image.FromFile(p.Tag.ToString() + ".png");
                }
            }
        }
        void hide()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Image = Image.FromFile("0.png");
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            
            show();
            Application.DoEvents();
            System.Threading.Thread.Sleep(350);
            hide();

        }
        void visible()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Visible = true;
                }
            }
        }
        void start()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Enabled = true;
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
            font();
            back();
            tag();
            visible();
            start();
            Match = 8;
            l = 0;
            time = 60;
            timer1.Enabled = true;

        }
        void stop()
        {
            foreach (Control p in this.Controls)
            {
                if (p is PictureBox)
                {
                    (p as PictureBox).Enabled = false;
                }
                
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            time -= 1;
            label1.Text = "Timer =" + time;
            if (time == 0)
            {
                label1.Text = "Game Finished!";
                this.Enabled = true;
                stop();
                timer1.Enabled = false;
                
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
