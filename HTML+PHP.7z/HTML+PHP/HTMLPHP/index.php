
<html>
<head>
    <title>FORM</title>
</head>
<body>

<form name="" method="post" action="contact.php">
    User Name:<br>
    <input type="text" name="un">
    <br>
	 Full Name:<br>
    <input type="text" name="name">
    <br>
    Email:<br>
    <input type="text" name="email">
    <br>

    Phone No:<br>
    <input type="text" name="pno">
    <br>

    Password:<br>
    <input type="text" name="pw">
    <br>
	Confirm Password:<br>
    <input type="text" name="cpw">
    <br>

   
	
  <input type="radio" name="gender" value="male" checked> Male
  <input type="radio" name="gender" value="female"> Female
  <input type="radio" name="gender" value="other"> Other<br>
  
  <input type="checkbox" name="SSC" value="ssc"> SSC
  <input type="checkbox" name="HSC" value="hsc"> HSC
  <input type="checkbox" name="BSC" value="ssc"> BSC
  <input type="checkbox" name="MSC" value="hsc"> MSC<br>
  
   <input type="submit" value="Submit">
    <input type="reset">
	<br>

</form>
</body>
</html>


