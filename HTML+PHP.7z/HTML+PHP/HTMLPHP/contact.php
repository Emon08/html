<?php
$username=$_POST['un'];
echo "Username: ".$username ;

$fullname=$_POST['name'];
echo "<br>Fullname: ".$fullname;

$email=$_POST['email'];
echo "<br>Email: ".$email;

$pno=$_POST['pno'];
echo "<br>Phone No: ".$pno;

$password=$_POST['pw'];
echo "<br>Password: ".$password;

$cpw=$_POST['cpw'];
echo "<br>Confirm Password: ".$cpw;

$gender=$_POST['gender'];
echo "<br>Gender: ".$gender;

$ssc=$_POST['']




?>