<?php

$conn= mysqli_connect('localhost','webtech','webtech','assignment');

//Write at least 2 functions for open and close connection to database.
?>