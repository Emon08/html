<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"

<html>
<head>
    <title>Title</title>
</head>
<body>
File Write:
<hr>
<form name="xmlwrite" method="post" action="write.php">
    <table>
        <tr>
            <td>Menu</td>
            <td>:</td>
            <td><input type="text" name="menu"/></td>
        </tr>
        <tr>
            <td>Item</td>
            <td>:</td>
            <td><input type="text" name="item"/></td>
        </tr>
		<tr>
            <td>Price</td>
            <td>:</td>
            <td><input type="text" name="price"/></td>
        </tr>
        <tr>
            <td><input type="submit"/></td>
           
            
        </tr>
    </table>
</form>
<hr>
XML Read
<hr>
<a href='read.php'>Read XML</a>
</body>
</html>